import { getStore } from "@netlify/blobs";

const DEFAULTS = { products: [], payment: { qr: "/qr.png", qrUrl: "/qr.png" }, settings: {}, orders: [] };
const store = getStore("blackcard-market");

async function getState(){
  const state = await store.get("state", { type: "json" });
  return state || DEFAULTS;
}
function json(data,status=200){
  return {status,headers:{"content-type":"application/json","cache-control":"no-store"},body:JSON.stringify(data)};
}
export default async (request) => {
  try{
    if(request.method==="GET") return json(await getState());
    if(request.method!=="POST") return json({error:"Method not allowed"},405);
    const body=await request.json();
    const state=await getState();
    const adminPass=process.env.BCM_ADMIN_PASSWORD || "RAJAJI";
    const supplied=request.headers.get("x-bcm-admin-password") || "";
    if(body.action==="auth") return supplied===adminPass ? json({ok:true}) : json({ok:false},401);
    if(body.action!=="save") return json({error:"Invalid action"},400);

    // Orders may be submitted by visitors; all other shared settings require admin password.
    if(body.type==="orders"){
      if(!Array.isArray(body.data)) return json({error:"Invalid orders"},400);
      state.orders=body.data;
    } else {
      if(supplied!==adminPass) return json({error:"Unauthorized"},401);
      if(!["products","payment","settings"].includes(body.type)) return json({error:"Invalid type"},400);
      state[body.type]=body.data;
    }
    await store.set("state",JSON.stringify(state));
    return json({ok:true,state});
  }catch(e){ return json({error:"Server error",message:String(e.message||e)},500); }
};
