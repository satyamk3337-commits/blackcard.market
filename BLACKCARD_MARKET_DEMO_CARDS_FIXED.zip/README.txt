BLACKCARD MARKET starter

Open index.html for the storefront and admin.html for the admin prototype.

Features:
- Dark neon premium UI inspired by the supplied screenshots
- VISA / MASTERCARD / RUPAY tabs
- Product cards, tiers, limits, expiry and prices
- Demo checkout + local demo order history
- Admin product add/delete/reset
- Admin order status management
- Website settings
- QR/payment section intentionally locked; no QR-change control

IMPORTANT: This is a front-end prototype. It does not issue real cards, process real payments, or store full card numbers/CVV/PIN. For production, add a secure backend, authentication, database, audit logs and a compliant payment/card-issuing provider.
