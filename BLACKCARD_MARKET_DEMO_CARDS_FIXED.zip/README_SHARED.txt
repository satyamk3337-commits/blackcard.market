BLACKCARD MARKET — SHARED DATA SETUP

This version adds a Netlify Functions + Netlify Blobs shared backend.
Admin card/QR/settings changes are stored centrally, so other phones/browsers see them too.

DEPLOY:
1. Upload/deploy the bcm_work folder to Netlify (do not deploy only index.html).
2. In Netlify Site settings -> Environment variables, add:
   BCM_ADMIN_PASSWORD = RAJAJI
   You can change RAJAJI to another password later; the frontend admin password must match it.
3. Redeploy the site after adding the variable.

The backend endpoint is /.netlify/functions/api.
The public storefront reads shared products/payment/settings from the backend.
Admin writes require the admin password header. Orders can be submitted by visitors and are stored centrally.

IMPORTANT:
- This is still a demo marketplace and does not issue real cards or process real payments.
- Do not store real full payment-card numbers, CVV, PINs, or other sensitive card credentials.
- If you later add real payments/cards, use a compliant payment/card-issuing provider and proper authentication.


QR: The provided QR image is included as /qr.png and is shown by default to new visitors in checkout. Admin changes are shared through the Netlify Blobs backend.
